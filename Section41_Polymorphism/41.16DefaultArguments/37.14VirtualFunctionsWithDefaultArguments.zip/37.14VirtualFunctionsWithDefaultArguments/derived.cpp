#include "derived.h"

Derived::Derived()
{
}

Derived::~Derived()
{
}

