#include "base.h"

Base::Base()
{
}

Base::~Base()
{
}

