#include "animal.h"

Animal::Animal(const std::string& description)
    : m_description(description)
{
}

Animal::~Animal()
{
}

