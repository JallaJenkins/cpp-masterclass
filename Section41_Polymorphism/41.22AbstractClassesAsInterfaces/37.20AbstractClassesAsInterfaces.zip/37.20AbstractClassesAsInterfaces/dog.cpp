#include "dog.h"

Dog::Dog(const std::string& fur_style, const std::string& description)
    : Feline(fur_style,description)
{
}

Dog::~Dog()
{
}

