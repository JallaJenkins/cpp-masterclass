#include "crow.h"

Crow::Crow(const std::string& wing_color, const std::string& description)
    : Bird(wing_color,description)
{
}

Crow::~Crow()
{
}

