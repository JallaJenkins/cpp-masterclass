#include "pigeon.h"

Pigeon::Pigeon(std::string_view wing_color, std::string_view description)
    : Bird(wing_color,description)
{
}

Pigeon::~Pigeon()
{
}

