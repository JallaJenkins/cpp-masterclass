#ifndef WILD_CAT_H
#define WILD_CAT_H
#include "cat.h"
class WildCat /*: public Cat*/ // Can not derive from final base class
{
public:
    WildCat();
    ~WildCat();

};

#endif // WILD_CAT_H
