#include "wildcat.h"

WildCat::WildCat()
{
}

WildCat::~WildCat()
{
}

