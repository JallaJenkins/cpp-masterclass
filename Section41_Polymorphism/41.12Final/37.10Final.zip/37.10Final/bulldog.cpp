#include "bulldog.h"

BullDog::BullDog()
{
}

BullDog::~BullDog()
{
}

